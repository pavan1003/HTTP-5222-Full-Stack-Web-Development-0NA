export default function Hero() {
  return (
    <section className="hero">
      <h2>Welcome to Pet Care Tips</h2>
      <p>Your one-stop destination for all pet care information.</p>
    </section>
  );
}
