export default function Footer() {
  return(
    <footer id="footer">
      <p>&copy; Copyright Pet Care, 2024.</p>
    </footer>
  )
}